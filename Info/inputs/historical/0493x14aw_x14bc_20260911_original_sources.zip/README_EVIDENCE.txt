SRC_GPU-SURF 0493x14aw -> x14bc evidence package, 2026-09-11

Images are user-supplied screen captures from the corresponding chat sequence:
- gamma12_*: x14ay gamma=12 particle-refinement smoke; interface remained visibly rough.
- gamma8_kBTL_0p015625_*: gamma=8, liquid kBT halved from 0.03125; visible improvement but remaining roughness.
- gamma8_kBTL_0p0078125_*: gamma=8, liquid kBT=0.0078125; convincing interface regularization.
- x14bc_pulsed_smoke_*: cold-liquid x14bc, global x14ba pulse enabled, 300-step integration smoke; visual path operational.

The TG128 log is the exact uploaded log used to calibrate the selected cold liquid.
The patch/runner ZIPs are the exact generated packages from the chat.
MANIFEST_SHA256.txt records the SHA-256 of every preserved payload.
